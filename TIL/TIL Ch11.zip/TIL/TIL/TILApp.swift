import SwiftUI

@main
struct TILApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.textCase, .uppercase)
        }
    }
}
