import Foundation

class ViewState: ObservableObject {
    @Published var showAllCards = false
}