import Foundation

enum CardModal {
    case photoPicker, framePicker, stickerPicker, textPicker
}