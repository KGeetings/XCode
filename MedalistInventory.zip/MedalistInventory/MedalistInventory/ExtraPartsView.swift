//
//  ExtraPartsView.swift
//  Medalist
//
//  Created by Kenyon on 3/28/23.
//

import SwiftUI

struct ExtraPartsView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct ExtraPartsView_Previews: PreviewProvider {
    static var previews: some View {
        ExtraPartsView()
    }
}
